package app;

import mechanic.*;

public class Main
{
    static Game game;
    public static void main(String[] Args)
    {
        game = new Game(false);
        Window window = new Window();
    }
}
